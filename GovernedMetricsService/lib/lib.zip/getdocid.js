var qrsInteract = require('./qrsinteractions');
var Promise = require('bluebird');
var config = require('./config');

var getDocId = 
{
	getDocId: function(appName)
	{
		return new Promise(function(resolve, reject)
		{
			console.log('running getdoc.getDocID');
			var path = "https://" + config.hostname + ":" + config.qrsPort + "/qrs/app"
			path += "?xrfkey=ABCDEFG123456789&filter=name eq '" + appName + "'";
			console.log("QRS Path: " + path);
			//add cookies here and use the same session
			qrsInteract.get(path)
			.then(function(result)
			{
				console.log('Metrics Library id: ' + result[0].id);
				resolve(result[0].id);
			})
			.catch(function(error)
			{
				console.log('Error at getdocid.js');
				console.log(error);
				reject(new Error(error));
			});
		});
	}
};

module.exports = getDocId;