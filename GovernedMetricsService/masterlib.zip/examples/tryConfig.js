var config = require('../config/config');

console.log(config.logPath);
console.log(config.logFile);